
<footer id="footer">
	<ul>Our Team
		<li><a>Khoirul Ansori</a></li>
		<li><a>Egar Caesario F</a></li>
		<li><a>Ahmad Fahros Farhat A</a></li>
		<li><a>Anandito Wisnu Widya P</a></li>
	</ul>
</footer>